/** Automatically generated file. DO NOT MODIFY */
package com.iut.dawin.snow;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}